##########  GRAPHE ET ONTOLOGIES    ##########
##########          README          ##########

# Windows

Par l'exécutable 'GandO.exe' ou par l'archive Java.
    java -jar GandO.jar

# Linux

Par l'archive Java
    java -jar GandO.jar